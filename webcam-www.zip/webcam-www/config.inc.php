<?php
	require_once('mysql.class.php');
	define("_DB_SERVER_", "dbserver");
	define("_DB_USER_", "dbuser");
	define("_DB_PASSWD_", "dbpassword");
	define("_DB_NAME_", "dbname");
	define("_DB_TABLE_", "tablename");
	$token = 'your-private-token';
?>